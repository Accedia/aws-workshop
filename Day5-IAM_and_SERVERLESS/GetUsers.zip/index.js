const axios = require('axios');

exports.handler = async (event) => {
    const res = await axios.get('http://dummy.restapiexample.com/api/v1/employees').catch(err => {
        console.error("error", err);
        throw err;
    });
    
    console.log("result", res.data);
    
    return res.data;
};
